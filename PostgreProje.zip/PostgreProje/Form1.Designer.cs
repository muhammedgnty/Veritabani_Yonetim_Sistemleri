﻿using System;

namespace PostgreProje
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.kisiBilgileriGoster = new System.Windows.Forms.Button();
            this.iletisimBilgileriGoster = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bolgeleriGoster = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.yeniKisiEkle = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.bakanliklariGoster = new System.Windows.Forms.Button();
            this.sirketleriGoster = new System.Windows.Forms.Button();
            this.devletSirketleriGoster = new System.Windows.Forms.Button();
            this.ozelSirketleriGoster = new System.Windows.Forms.Button();
            this.medeniDurumGoster = new System.Windows.Forms.Button();
            this.calisanlarGoster = new System.Windows.Forms.Button();
            this.pozisyonlariGoster = new System.Windows.Forms.Button();
            this.bankaHesaplariGoster = new System.Windows.Forms.Button();
            this.sirketHesaplariGoster = new System.Windows.Forms.Button();
            this.kisiselHesaplariGoster = new System.Windows.Forms.Button();
            this.devletSirketiEkle = new System.Windows.Forms.Button();
            this.sirketNo = new System.Windows.Forms.TextBox();
            this.sirketAdi = new System.Windows.Forms.TextBox();
            this.sektor = new System.Windows.Forms.TextBox();
            this.sirketTuru = new System.Windows.Forms.TextBox();
            this.iletisimKoduu = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.kurulusTarihiii = new System.Windows.Forms.TextBox();
            this.bakanlikNoo = new System.Windows.Forms.TextBox();
            this.kurulusTarihi = new System.Windows.Forms.Label();
            this.bakanlikNumarasi = new System.Windows.Forms.Label();
            this.sahipTCNoo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.hisseMiktarii = new System.Windows.Forms.TextBox();
            this.calisanSayisii = new System.Windows.Forms.TextBox();
            this.ozelSirketEkle = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.calisanEkle = new System.Windows.Forms.Button();
            this.calisanNo1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.sirketNo1 = new System.Windows.Forms.TextBox();
            this.calisanTCNo1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.pozisyonNo1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.maasNo1 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.hesapNumarasiNo2 = new System.Windows.Forms.TextBox();
            this.bakiye2 = new System.Windows.Forms.TextBox();
            this.olusturulmaTarihi2 = new System.Windows.Forms.TextBox();
            this.hesabiKullananTCNo2 = new System.Windows.Forms.TextBox();
            this.hesapTuru2 = new System.Windows.Forms.TextBox();
            this.hesapAcilisAmac2 = new System.Windows.Forms.TextBox();
            this.sirketNo2 = new System.Windows.Forms.TextBox();
            this.TCNo2 = new System.Windows.Forms.TextBox();
            this.anneKizlikSoyad = new System.Windows.Forms.TextBox();
            this.sirketHesabiAc = new System.Windows.Forms.Button();
            this.kisiselHesapAc = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.kisiSil = new System.Windows.Forms.Button();
            this.devletSirketiSil = new System.Windows.Forms.Button();
            this.ozelSirketiSil = new System.Windows.Forms.Button();
            this.calisaniSil = new System.Windows.Forms.Button();
            this.bankaHesabiniSil = new System.Windows.Forms.Button();
            this.kisiSilText = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.silinecekDevletSirketiText = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.ozelSirketiSilText = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.calisaniSilText = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.bankaHesabiniSilText = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.kisiyiAra = new System.Windows.Forms.Button();
            this.duzenlenecekKisi = new System.Windows.Forms.Button();
            this.sirketiBulVeGetir = new System.Windows.Forms.Button();
            this.devletSirketininDuzenlemesi = new System.Windows.Forms.Button();
            this.ozelSirketiBulVeGetir = new System.Windows.Forms.Button();
            this.ozelSirketinDuzenlenmesi = new System.Windows.Forms.Button();
            this.calisaniBulVeGetir = new System.Windows.Forms.Button();
            this.calisaninDuzenlenmesi = new System.Windows.Forms.Button();
            this.sirketHesabiniBulVeGetir = new System.Windows.Forms.Button();
            this.sirketHesabiniDuzenle = new System.Windows.Forms.Button();
            this.kisiselHesabiBulVeGetir = new System.Windows.Forms.Button();
            this.kisiselHesabiniDuzenle = new System.Windows.Forms.Button();
            this.iletisimKoduText = new System.Windows.Forms.TextBox();
            this.telNo = new System.Windows.Forms.TextBox();
            this.ePosta = new System.Windows.Forms.TextBox();
            this.ilceKodu = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.iletisimEkle = new System.Windows.Forms.Button();
            this.iletisimiSil = new System.Windows.Forms.Button();
            this.iletisimKodu = new System.Windows.Forms.TextBox();
            this.iletisimiDuzenle = new System.Windows.Forms.Button();
            this.iletisimiBulVeGetir = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.Iller = new System.Windows.Forms.Button();
            this.ilceleriGoster = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.hesaptakiParayiGetirText = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.bakanlikAdiText = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // kisiBilgileriGoster
            // 
            this.kisiBilgileriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.kisiBilgileriGoster.Location = new System.Drawing.Point(43, 61);
            this.kisiBilgileriGoster.Name = "kisiBilgileriGoster";
            this.kisiBilgileriGoster.Size = new System.Drawing.Size(88, 36);
            this.kisiBilgileriGoster.TabIndex = 0;
            this.kisiBilgileriGoster.Text = "Kişiler";
            this.kisiBilgileriGoster.UseVisualStyleBackColor = false;
            this.kisiBilgileriGoster.Click += new System.EventHandler(this.button1_Click);
            // 
            // iletisimBilgileriGoster
            // 
            this.iletisimBilgileriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.iletisimBilgileriGoster.Location = new System.Drawing.Point(284, 61);
            this.iletisimBilgileriGoster.Name = "iletisimBilgileriGoster";
            this.iletisimBilgileriGoster.Size = new System.Drawing.Size(145, 36);
            this.iletisimBilgileriGoster.TabIndex = 1;
            this.iletisimBilgileriGoster.Text = "İletişim Bilgileri";
            this.iletisimBilgileriGoster.UseVisualStyleBackColor = false;
            this.iletisimBilgileriGoster.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Lavender;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(43, 425);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(692, 521);
            this.dataGridView1.TabIndex = 2;
            // 
            // bolgeleriGoster
            // 
            this.bolgeleriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.bolgeleriGoster.Location = new System.Drawing.Point(632, 61);
            this.bolgeleriGoster.Name = "bolgeleriGoster";
            this.bolgeleriGoster.Size = new System.Drawing.Size(103, 36);
            this.bolgeleriGoster.TabIndex = 3;
            this.bolgeleriGoster.Text = "Bölgeler";
            this.bolgeleriGoster.UseVisualStyleBackColor = false;
            this.bolgeleriGoster.Click += new System.EventHandler(this.bolgeleriGoster_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.Location = new System.Drawing.Point(38, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "TABLOLAR";
            // 
            // yeniKisiEkle
            // 
            this.yeniKisiEkle.BackColor = System.Drawing.Color.MistyRose;
            this.yeniKisiEkle.Location = new System.Drawing.Point(1811, 18);
            this.yeniKisiEkle.Name = "yeniKisiEkle";
            this.yeniKisiEkle.Size = new System.Drawing.Size(139, 45);
            this.yeniKisiEkle.TabIndex = 6;
            this.yeniKisiEkle.Text = "Kişi Ekle";
            this.yeniKisiEkle.UseVisualStyleBackColor = false;
            this.yeniKisiEkle.Click += new System.EventHandler(this.yeniKisiEkle_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.MistyRose;
            this.textBox1.Location = new System.Drawing.Point(788, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 22);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.MistyRose;
            this.textBox2.Location = new System.Drawing.Point(916, 41);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 22);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.MistyRose;
            this.textBox3.Location = new System.Drawing.Point(1045, 41);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(120, 22);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.MistyRose;
            this.textBox4.Location = new System.Drawing.Point(1174, 41);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(120, 22);
            this.textBox4.TabIndex = 10;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.MistyRose;
            this.textBox5.Location = new System.Drawing.Point(1300, 41);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(120, 22);
            this.textBox5.TabIndex = 11;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.MistyRose;
            this.textBox6.Location = new System.Drawing.Point(1426, 41);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(120, 22);
            this.textBox6.TabIndex = 12;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.MistyRose;
            this.textBox7.Location = new System.Drawing.Point(1552, 41);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(120, 22);
            this.textBox7.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(913, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Adı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1042, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Soyadı:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1171, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1297, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "Anne Adı:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1423, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 16);
            this.label6.TabIndex = 18;
            this.label6.Text = "Baba Adı:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1549, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "Medeni Durum No:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1675, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 16);
            this.label8.TabIndex = 20;
            this.label8.Text = "İletişim Kodu:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(785, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "TCNo:";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.MistyRose;
            this.textBox8.Location = new System.Drawing.Point(1678, 41);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(120, 22);
            this.textBox8.TabIndex = 22;
            // 
            // bakanliklariGoster
            // 
            this.bakanliklariGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.bakanliklariGoster.Location = new System.Drawing.Point(43, 108);
            this.bakanliklariGoster.Name = "bakanliklariGoster";
            this.bakanliklariGoster.Size = new System.Drawing.Size(98, 36);
            this.bakanliklariGoster.TabIndex = 23;
            this.bakanliklariGoster.Text = "Bakanlıklar";
            this.bakanliklariGoster.UseVisualStyleBackColor = false;
            this.bakanliklariGoster.Click += new System.EventHandler(this.bakanliklariGoster_Click);
            // 
            // sirketleriGoster
            // 
            this.sirketleriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.sirketleriGoster.Location = new System.Drawing.Point(147, 108);
            this.sirketleriGoster.Name = "sirketleriGoster";
            this.sirketleriGoster.Size = new System.Drawing.Size(94, 36);
            this.sirketleriGoster.TabIndex = 24;
            this.sirketleriGoster.Text = "Şirketler";
            this.sirketleriGoster.UseVisualStyleBackColor = false;
            this.sirketleriGoster.Click += new System.EventHandler(this.sirketleriGoster_Click);
            // 
            // devletSirketleriGoster
            // 
            this.devletSirketleriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.devletSirketleriGoster.Location = new System.Drawing.Point(390, 108);
            this.devletSirketleriGoster.Name = "devletSirketleriGoster";
            this.devletSirketleriGoster.Size = new System.Drawing.Size(140, 36);
            this.devletSirketleriGoster.TabIndex = 25;
            this.devletSirketleriGoster.Text = "Devlet Şirketleri";
            this.devletSirketleriGoster.UseVisualStyleBackColor = false;
            this.devletSirketleriGoster.Click += new System.EventHandler(this.devletSirketleriGoster_Click);
            // 
            // ozelSirketleriGoster
            // 
            this.ozelSirketleriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.ozelSirketleriGoster.Location = new System.Drawing.Point(247, 108);
            this.ozelSirketleriGoster.Name = "ozelSirketleriGoster";
            this.ozelSirketleriGoster.Size = new System.Drawing.Size(137, 36);
            this.ozelSirketleriGoster.TabIndex = 26;
            this.ozelSirketleriGoster.Text = "Özel Şirketler";
            this.ozelSirketleriGoster.UseVisualStyleBackColor = false;
            this.ozelSirketleriGoster.Click += new System.EventHandler(this.ozelSirketleriGoster_Click);
            // 
            // medeniDurumGoster
            // 
            this.medeniDurumGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.medeniDurumGoster.DialogResult = System.Windows.Forms.DialogResult.Retry;
            this.medeniDurumGoster.Location = new System.Drawing.Point(137, 61);
            this.medeniDurumGoster.Name = "medeniDurumGoster";
            this.medeniDurumGoster.Size = new System.Drawing.Size(141, 36);
            this.medeniDurumGoster.TabIndex = 27;
            this.medeniDurumGoster.Text = "Medeni Durum";
            this.medeniDurumGoster.UseVisualStyleBackColor = false;
            this.medeniDurumGoster.Click += new System.EventHandler(this.medeniDurumGoster_Click);
            // 
            // calisanlarGoster
            // 
            this.calisanlarGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.calisanlarGoster.Location = new System.Drawing.Point(536, 108);
            this.calisanlarGoster.Name = "calisanlarGoster";
            this.calisanlarGoster.Size = new System.Drawing.Size(97, 36);
            this.calisanlarGoster.TabIndex = 28;
            this.calisanlarGoster.Text = "Çalışanlar";
            this.calisanlarGoster.UseVisualStyleBackColor = false;
            this.calisanlarGoster.Click += new System.EventHandler(this.calisanlarGoster_Click);
            // 
            // pozisyonlariGoster
            // 
            this.pozisyonlariGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.pozisyonlariGoster.Location = new System.Drawing.Point(639, 107);
            this.pozisyonlariGoster.Name = "pozisyonlariGoster";
            this.pozisyonlariGoster.Size = new System.Drawing.Size(96, 36);
            this.pozisyonlariGoster.TabIndex = 29;
            this.pozisyonlariGoster.Text = "Pozisyonlar";
            this.pozisyonlariGoster.UseVisualStyleBackColor = false;
            this.pozisyonlariGoster.Click += new System.EventHandler(this.pozisyonlariGoster_Click);
            // 
            // bankaHesaplariGoster
            // 
            this.bankaHesaplariGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.bankaHesaplariGoster.Location = new System.Drawing.Point(43, 157);
            this.bankaHesaplariGoster.Name = "bankaHesaplariGoster";
            this.bankaHesaplariGoster.Size = new System.Drawing.Size(174, 36);
            this.bankaHesaplariGoster.TabIndex = 30;
            this.bankaHesaplariGoster.Text = "Banka Hesapları";
            this.bankaHesaplariGoster.UseVisualStyleBackColor = false;
            this.bankaHesaplariGoster.Click += new System.EventHandler(this.bankaHesaplariGoster_Click);
            // 
            // sirketHesaplariGoster
            // 
            this.sirketHesaplariGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.sirketHesaplariGoster.Location = new System.Drawing.Point(297, 157);
            this.sirketHesaplariGoster.Name = "sirketHesaplariGoster";
            this.sirketHesaplariGoster.Size = new System.Drawing.Size(174, 36);
            this.sirketHesaplariGoster.TabIndex = 31;
            this.sirketHesaplariGoster.Text = "Şirket Hesapları";
            this.sirketHesaplariGoster.UseVisualStyleBackColor = false;
            this.sirketHesaplariGoster.Click += new System.EventHandler(this.sirketHesaplariGoster_Click);
            // 
            // kisiselHesaplariGoster
            // 
            this.kisiselHesaplariGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.kisiselHesaplariGoster.Location = new System.Drawing.Point(561, 157);
            this.kisiselHesaplariGoster.Name = "kisiselHesaplariGoster";
            this.kisiselHesaplariGoster.Size = new System.Drawing.Size(174, 36);
            this.kisiselHesaplariGoster.TabIndex = 32;
            this.kisiselHesaplariGoster.Text = "Kişisel Hesaplar";
            this.kisiselHesaplariGoster.UseVisualStyleBackColor = false;
            this.kisiselHesaplariGoster.Click += new System.EventHandler(this.kisiselHesaplariGoster_Click);
            // 
            // devletSirketiEkle
            // 
            this.devletSirketiEkle.BackColor = System.Drawing.Color.MistyRose;
            this.devletSirketiEkle.Location = new System.Drawing.Point(1811, 249);
            this.devletSirketiEkle.Name = "devletSirketiEkle";
            this.devletSirketiEkle.Size = new System.Drawing.Size(139, 45);
            this.devletSirketiEkle.TabIndex = 33;
            this.devletSirketiEkle.Text = "Devlet Şirketi Ekle";
            this.devletSirketiEkle.UseVisualStyleBackColor = false;
            this.devletSirketiEkle.Click += new System.EventHandler(this.devletSirketiEkle_Click);
            // 
            // sirketNo
            // 
            this.sirketNo.BackColor = System.Drawing.Color.MistyRose;
            this.sirketNo.Location = new System.Drawing.Point(788, 316);
            this.sirketNo.Name = "sirketNo";
            this.sirketNo.Size = new System.Drawing.Size(120, 22);
            this.sirketNo.TabIndex = 34;
            // 
            // sirketAdi
            // 
            this.sirketAdi.BackColor = System.Drawing.Color.MistyRose;
            this.sirketAdi.Location = new System.Drawing.Point(927, 316);
            this.sirketAdi.Name = "sirketAdi";
            this.sirketAdi.Size = new System.Drawing.Size(120, 22);
            this.sirketAdi.TabIndex = 35;
            // 
            // sektor
            // 
            this.sektor.BackColor = System.Drawing.Color.MistyRose;
            this.sektor.Location = new System.Drawing.Point(1068, 316);
            this.sektor.Name = "sektor";
            this.sektor.Size = new System.Drawing.Size(120, 22);
            this.sektor.TabIndex = 36;
            // 
            // sirketTuru
            // 
            this.sirketTuru.BackColor = System.Drawing.Color.MistyRose;
            this.sirketTuru.Location = new System.Drawing.Point(1203, 316);
            this.sirketTuru.Name = "sirketTuru";
            this.sirketTuru.Size = new System.Drawing.Size(120, 22);
            this.sirketTuru.TabIndex = 37;
            // 
            // iletisimKoduu
            // 
            this.iletisimKoduu.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimKoduu.Location = new System.Drawing.Point(1336, 316);
            this.iletisimKoduu.Name = "iletisimKoduu";
            this.iletisimKoduu.Size = new System.Drawing.Size(120, 22);
            this.iletisimKoduu.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(785, 293);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 16);
            this.label10.TabIndex = 39;
            this.label10.Text = "Şirket Numarası:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(924, 293);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 16);
            this.label11.TabIndex = 40;
            this.label11.Text = "Şirket Adı:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1065, 293);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 16);
            this.label12.TabIndex = 41;
            this.label12.Text = "Sektör:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1200, 293);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 16);
            this.label13.TabIndex = 42;
            this.label13.Text = "Şirket Türü (O/D):";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1333, 293);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 16);
            this.label14.TabIndex = 43;
            this.label14.Text = "İletişim Kodu:";
            // 
            // kurulusTarihiii
            // 
            this.kurulusTarihiii.BackColor = System.Drawing.Color.MistyRose;
            this.kurulusTarihiii.Location = new System.Drawing.Point(1499, 272);
            this.kurulusTarihiii.Name = "kurulusTarihiii";
            this.kurulusTarihiii.Size = new System.Drawing.Size(120, 22);
            this.kurulusTarihiii.TabIndex = 44;
            // 
            // bakanlikNoo
            // 
            this.bakanlikNoo.BackColor = System.Drawing.Color.MistyRose;
            this.bakanlikNoo.Location = new System.Drawing.Point(1656, 272);
            this.bakanlikNoo.Name = "bakanlikNoo";
            this.bakanlikNoo.Size = new System.Drawing.Size(120, 22);
            this.bakanlikNoo.TabIndex = 45;
            // 
            // kurulusTarihi
            // 
            this.kurulusTarihi.AutoSize = true;
            this.kurulusTarihi.Location = new System.Drawing.Point(1496, 249);
            this.kurulusTarihi.Name = "kurulusTarihi";
            this.kurulusTarihi.Size = new System.Drawing.Size(90, 16);
            this.kurulusTarihi.TabIndex = 46;
            this.kurulusTarihi.Text = "Kuruluş Tarihi:";
            // 
            // bakanlikNumarasi
            // 
            this.bakanlikNumarasi.AutoSize = true;
            this.bakanlikNumarasi.Location = new System.Drawing.Point(1653, 249);
            this.bakanlikNumarasi.Name = "bakanlikNumarasi";
            this.bakanlikNumarasi.Size = new System.Drawing.Size(123, 16);
            this.bakanlikNumarasi.TabIndex = 47;
            this.bakanlikNumarasi.Text = "Bakanlık Numarası:";
            // 
            // sahipTCNoo
            // 
            this.sahipTCNoo.BackColor = System.Drawing.Color.MistyRose;
            this.sahipTCNoo.Location = new System.Drawing.Point(1499, 358);
            this.sahipTCNoo.Name = "sahipTCNoo";
            this.sahipTCNoo.Size = new System.Drawing.Size(120, 22);
            this.sahipTCNoo.TabIndex = 48;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1496, 339);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 16);
            this.label15.TabIndex = 49;
            this.label15.Text = "TC Numarası: ";
            // 
            // hisseMiktarii
            // 
            this.hisseMiktarii.BackColor = System.Drawing.Color.MistyRose;
            this.hisseMiktarii.Location = new System.Drawing.Point(1336, 553);
            this.hisseMiktarii.Name = "hisseMiktarii";
            this.hisseMiktarii.Size = new System.Drawing.Size(120, 22);
            this.hisseMiktarii.TabIndex = 50;
            // 
            // calisanSayisii
            // 
            this.calisanSayisii.BackColor = System.Drawing.Color.MistyRose;
            this.calisanSayisii.Location = new System.Drawing.Point(1656, 358);
            this.calisanSayisii.Name = "calisanSayisii";
            this.calisanSayisii.Size = new System.Drawing.Size(120, 22);
            this.calisanSayisii.TabIndex = 51;
            // 
            // ozelSirketEkle
            // 
            this.ozelSirketEkle.BackColor = System.Drawing.Color.MistyRose;
            this.ozelSirketEkle.Location = new System.Drawing.Point(1811, 335);
            this.ozelSirketEkle.Name = "ozelSirketEkle";
            this.ozelSirketEkle.Size = new System.Drawing.Size(139, 45);
            this.ozelSirketEkle.TabIndex = 52;
            this.ozelSirketEkle.Text = "Özel Şirket Ekle";
            this.ozelSirketEkle.UseVisualStyleBackColor = false;
            this.ozelSirketEkle.Click += new System.EventHandler(this.ozelSirketEkle_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1333, 534);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 16);
            this.label16.TabIndex = 53;
            this.label16.Text = "Hisse Miktarı:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1653, 339);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 16);
            this.label17.TabIndex = 54;
            this.label17.Text = "Çalışan Sayısı:";
            // 
            // calisanEkle
            // 
            this.calisanEkle.BackColor = System.Drawing.Color.MistyRose;
            this.calisanEkle.Location = new System.Drawing.Point(1609, 530);
            this.calisanEkle.Name = "calisanEkle";
            this.calisanEkle.Size = new System.Drawing.Size(139, 45);
            this.calisanEkle.TabIndex = 55;
            this.calisanEkle.Text = "Çalışan Ekle";
            this.calisanEkle.UseVisualStyleBackColor = false;
            this.calisanEkle.Click += new System.EventHandler(this.calisanEkle_Click);
            // 
            // calisanNo1
            // 
            this.calisanNo1.BackColor = System.Drawing.Color.MistyRose;
            this.calisanNo1.Location = new System.Drawing.Point(788, 553);
            this.calisanNo1.Name = "calisanNo1";
            this.calisanNo1.Size = new System.Drawing.Size(120, 22);
            this.calisanNo1.TabIndex = 56;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(924, 534);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(105, 16);
            this.label18.TabIndex = 57;
            this.label18.Text = "Şirket Numarası:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1065, 534);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 16);
            this.label19.TabIndex = 58;
            this.label19.Text = "TCNo:";
            // 
            // sirketNo1
            // 
            this.sirketNo1.BackColor = System.Drawing.Color.MistyRose;
            this.sirketNo1.Location = new System.Drawing.Point(927, 553);
            this.sirketNo1.Name = "sirketNo1";
            this.sirketNo1.Size = new System.Drawing.Size(120, 22);
            this.sirketNo1.TabIndex = 59;
            // 
            // calisanTCNo1
            // 
            this.calisanTCNo1.BackColor = System.Drawing.Color.MistyRose;
            this.calisanTCNo1.Location = new System.Drawing.Point(1068, 553);
            this.calisanTCNo1.Name = "calisanTCNo1";
            this.calisanTCNo1.Size = new System.Drawing.Size(120, 22);
            this.calisanTCNo1.TabIndex = 60;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1200, 534);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 16);
            this.label20.TabIndex = 61;
            this.label20.Text = "Pozisyon No:";
            // 
            // pozisyonNo1
            // 
            this.pozisyonNo1.BackColor = System.Drawing.Color.MistyRose;
            this.pozisyonNo1.Location = new System.Drawing.Point(1203, 553);
            this.pozisyonNo1.Name = "pozisyonNo1";
            this.pozisyonNo1.Size = new System.Drawing.Size(120, 22);
            this.pozisyonNo1.TabIndex = 62;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(785, 534);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(116, 16);
            this.label21.TabIndex = 63;
            this.label21.Text = "Çalışan Numarası:";
            // 
            // maasNo1
            // 
            this.maasNo1.BackColor = System.Drawing.Color.MistyRose;
            this.maasNo1.Location = new System.Drawing.Point(1468, 553);
            this.maasNo1.Name = "maasNo1";
            this.maasNo1.Size = new System.Drawing.Size(120, 22);
            this.maasNo1.TabIndex = 64;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1465, 534);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 16);
            this.label22.TabIndex = 65;
            this.label22.Text = "Maaşı:";
            // 
            // hesapNumarasiNo2
            // 
            this.hesapNumarasiNo2.BackColor = System.Drawing.Color.MistyRose;
            this.hesapNumarasiNo2.Location = new System.Drawing.Point(788, 721);
            this.hesapNumarasiNo2.Name = "hesapNumarasiNo2";
            this.hesapNumarasiNo2.Size = new System.Drawing.Size(120, 22);
            this.hesapNumarasiNo2.TabIndex = 66;
            // 
            // bakiye2
            // 
            this.bakiye2.BackColor = System.Drawing.Color.MistyRose;
            this.bakiye2.Location = new System.Drawing.Point(927, 721);
            this.bakiye2.Name = "bakiye2";
            this.bakiye2.Size = new System.Drawing.Size(120, 22);
            this.bakiye2.TabIndex = 67;
            // 
            // olusturulmaTarihi2
            // 
            this.olusturulmaTarihi2.BackColor = System.Drawing.Color.MistyRose;
            this.olusturulmaTarihi2.Location = new System.Drawing.Point(1068, 721);
            this.olusturulmaTarihi2.Name = "olusturulmaTarihi2";
            this.olusturulmaTarihi2.Size = new System.Drawing.Size(120, 22);
            this.olusturulmaTarihi2.TabIndex = 68;
            // 
            // hesabiKullananTCNo2
            // 
            this.hesabiKullananTCNo2.BackColor = System.Drawing.Color.MistyRose;
            this.hesabiKullananTCNo2.Location = new System.Drawing.Point(1203, 721);
            this.hesabiKullananTCNo2.Name = "hesabiKullananTCNo2";
            this.hesabiKullananTCNo2.Size = new System.Drawing.Size(120, 22);
            this.hesabiKullananTCNo2.TabIndex = 69;
            // 
            // hesapTuru2
            // 
            this.hesapTuru2.BackColor = System.Drawing.Color.MistyRose;
            this.hesapTuru2.Location = new System.Drawing.Point(1336, 721);
            this.hesapTuru2.Name = "hesapTuru2";
            this.hesapTuru2.Size = new System.Drawing.Size(120, 22);
            this.hesapTuru2.TabIndex = 70;
            // 
            // hesapAcilisAmac2
            // 
            this.hesapAcilisAmac2.BackColor = System.Drawing.Color.MistyRose;
            this.hesapAcilisAmac2.Location = new System.Drawing.Point(1499, 680);
            this.hesapAcilisAmac2.Name = "hesapAcilisAmac2";
            this.hesapAcilisAmac2.Size = new System.Drawing.Size(120, 22);
            this.hesapAcilisAmac2.TabIndex = 71;
            // 
            // sirketNo2
            // 
            this.sirketNo2.BackColor = System.Drawing.Color.MistyRose;
            this.sirketNo2.Location = new System.Drawing.Point(1656, 680);
            this.sirketNo2.Name = "sirketNo2";
            this.sirketNo2.Size = new System.Drawing.Size(123, 22);
            this.sirketNo2.TabIndex = 72;
            // 
            // TCNo2
            // 
            this.TCNo2.BackColor = System.Drawing.Color.MistyRose;
            this.TCNo2.Location = new System.Drawing.Point(1661, 762);
            this.TCNo2.Name = "TCNo2";
            this.TCNo2.Size = new System.Drawing.Size(112, 22);
            this.TCNo2.TabIndex = 73;
            // 
            // anneKizlikSoyad
            // 
            this.anneKizlikSoyad.BackColor = System.Drawing.Color.MistyRose;
            this.anneKizlikSoyad.Location = new System.Drawing.Point(1499, 762);
            this.anneKizlikSoyad.Name = "anneKizlikSoyad";
            this.anneKizlikSoyad.Size = new System.Drawing.Size(120, 22);
            this.anneKizlikSoyad.TabIndex = 74;
            // 
            // sirketHesabiAc
            // 
            this.sirketHesabiAc.BackColor = System.Drawing.Color.MistyRose;
            this.sirketHesabiAc.Location = new System.Drawing.Point(1811, 657);
            this.sirketHesabiAc.Name = "sirketHesabiAc";
            this.sirketHesabiAc.Size = new System.Drawing.Size(139, 45);
            this.sirketHesabiAc.TabIndex = 75;
            this.sirketHesabiAc.Text = "Şirket Hesabı Aç";
            this.sirketHesabiAc.UseVisualStyleBackColor = false;
            this.sirketHesabiAc.Click += new System.EventHandler(this.sirketHesabiAc_Click_1);
            // 
            // kisiselHesapAc
            // 
            this.kisiselHesapAc.BackColor = System.Drawing.Color.MistyRose;
            this.kisiselHesapAc.Location = new System.Drawing.Point(1811, 743);
            this.kisiselHesapAc.Name = "kisiselHesapAc";
            this.kisiselHesapAc.Size = new System.Drawing.Size(139, 45);
            this.kisiselHesapAc.TabIndex = 76;
            this.kisiselHesapAc.Text = "Kişisel Hesap Aç";
            this.kisiselHesapAc.UseVisualStyleBackColor = false;
            this.kisiselHesapAc.Click += new System.EventHandler(this.kisiselHesapAc_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(785, 702);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(112, 16);
            this.label23.TabIndex = 77;
            this.label23.Text = "Hesap Numarası:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(924, 702);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 16);
            this.label24.TabIndex = 78;
            this.label24.Text = "Bakiye:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1065, 702);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(117, 16);
            this.label25.TabIndex = 79;
            this.label25.Text = "Oluşturulma Tarihi:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1200, 702);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(124, 16);
            this.label26.TabIndex = 80;
            this.label26.Text = "Kullanan Kişi TCNo:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1333, 702);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(110, 16);
            this.label27.TabIndex = 81;
            this.label27.Text = "Hesap Türü(S/K):";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1496, 659);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(127, 16);
            this.label28.TabIndex = 82;
            this.label28.Text = "Hesap Açılış Amacı:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1653, 659);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 16);
            this.label29.TabIndex = 83;
            this.label29.Text = "Şirket Numarası:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1496, 743);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(120, 16);
            this.label30.TabIndex = 84;
            this.label30.Text = "Anne Kızlık Soyadı:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1658, 743);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(46, 16);
            this.label31.TabIndex = 85;
            this.label31.Text = "TCNo:";
            // 
            // kisiSil
            // 
            this.kisiSil.BackColor = System.Drawing.Color.MistyRose;
            this.kisiSil.Location = new System.Drawing.Point(1650, 78);
            this.kisiSil.Name = "kisiSil";
            this.kisiSil.Size = new System.Drawing.Size(139, 45);
            this.kisiSil.TabIndex = 86;
            this.kisiSil.Text = "Kişi Sil";
            this.kisiSil.UseVisualStyleBackColor = false;
            this.kisiSil.Click += new System.EventHandler(this.kisiSil_Click);
            // 
            // devletSirketiSil
            // 
            this.devletSirketiSil.BackColor = System.Drawing.Color.MistyRose;
            this.devletSirketiSil.Location = new System.Drawing.Point(1650, 400);
            this.devletSirketiSil.Name = "devletSirketiSil";
            this.devletSirketiSil.Size = new System.Drawing.Size(139, 45);
            this.devletSirketiSil.TabIndex = 87;
            this.devletSirketiSil.Text = "Devlet Şirketi Sil";
            this.devletSirketiSil.UseVisualStyleBackColor = false;
            this.devletSirketiSil.Click += new System.EventHandler(this.devletSirketiSil_Click);
            // 
            // ozelSirketiSil
            // 
            this.ozelSirketiSil.BackColor = System.Drawing.Color.MistyRose;
            this.ozelSirketiSil.Location = new System.Drawing.Point(1650, 464);
            this.ozelSirketiSil.Name = "ozelSirketiSil";
            this.ozelSirketiSil.Size = new System.Drawing.Size(139, 45);
            this.ozelSirketiSil.TabIndex = 88;
            this.ozelSirketiSil.Text = "Özel Şirketi Sil";
            this.ozelSirketiSil.UseVisualStyleBackColor = false;
            this.ozelSirketiSil.Click += new System.EventHandler(this.ozelSirketiSil_Click);
            // 
            // calisaniSil
            // 
            this.calisaniSil.BackColor = System.Drawing.Color.MistyRose;
            this.calisaniSil.Location = new System.Drawing.Point(1650, 590);
            this.calisaniSil.Name = "calisaniSil";
            this.calisaniSil.Size = new System.Drawing.Size(139, 45);
            this.calisaniSil.TabIndex = 89;
            this.calisaniSil.Text = "Çalışanı Sil";
            this.calisaniSil.UseVisualStyleBackColor = false;
            this.calisaniSil.Click += new System.EventHandler(this.calisaniSil_Click);
            // 
            // bankaHesabiniSil
            // 
            this.bankaHesabiniSil.BackColor = System.Drawing.Color.MistyRose;
            this.bankaHesabiniSil.Location = new System.Drawing.Point(1650, 857);
            this.bankaHesabiniSil.Name = "bankaHesabiniSil";
            this.bankaHesabiniSil.Size = new System.Drawing.Size(139, 45);
            this.bankaHesabiniSil.TabIndex = 90;
            this.bankaHesabiniSil.Text = "Banka Hesabını Sil";
            this.bankaHesabiniSil.UseVisualStyleBackColor = false;
            this.bankaHesabiniSil.Click += new System.EventHandler(this.bankaHesabiniSil_Click);
            // 
            // kisiSilText
            // 
            this.kisiSilText.BackColor = System.Drawing.Color.MistyRose;
            this.kisiSilText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.kisiSilText.Location = new System.Drawing.Point(1265, 89);
            this.kisiSilText.Name = "kisiSilText";
            this.kisiSilText.Size = new System.Drawing.Size(196, 26);
            this.kisiSilText.TabIndex = 92;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label32.Location = new System.Drawing.Point(919, 89);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(291, 20);
            this.label32.TabIndex = 93;
            this.label32.Text = "Silinecek/Düzenlenecek Kişinin TC\'si:";
            // 
            // silinecekDevletSirketiText
            // 
            this.silinecekDevletSirketiText.BackColor = System.Drawing.Color.MistyRose;
            this.silinecekDevletSirketiText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.silinecekDevletSirketiText.Location = new System.Drawing.Point(1270, 419);
            this.silinecekDevletSirketiText.Name = "silinecekDevletSirketiText";
            this.silinecekDevletSirketiText.Size = new System.Drawing.Size(196, 26);
            this.silinecekDevletSirketiText.TabIndex = 94;
            this.silinecekDevletSirketiText.TextChanged += new System.EventHandler(this.silinecekDevletSirketiText_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label33.Location = new System.Drawing.Point(839, 425);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(383, 20);
            this.label33.TabIndex = 95;
            this.label33.Text = "Silinecek/Düzenlenecek Devlet Şirketin Numarası:";
            // 
            // ozelSirketiSilText
            // 
            this.ozelSirketiSilText.BackColor = System.Drawing.Color.MistyRose;
            this.ozelSirketiSilText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ozelSirketiSilText.Location = new System.Drawing.Point(1270, 483);
            this.ozelSirketiSilText.Name = "ozelSirketiSilText";
            this.ozelSirketiSilText.Size = new System.Drawing.Size(196, 26);
            this.ozelSirketiSilText.TabIndex = 96;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label34.Location = new System.Drawing.Point(847, 486);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(375, 20);
            this.label34.TabIndex = 97;
            this.label34.Text = "Silinecek /Düzenlenecek Özel Şirketin Numarası:";
            // 
            // calisaniSilText
            // 
            this.calisaniSilText.BackColor = System.Drawing.Color.MistyRose;
            this.calisaniSilText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.calisaniSilText.Location = new System.Drawing.Point(1268, 609);
            this.calisaniSilText.Name = "calisaniSilText";
            this.calisaniSilText.Size = new System.Drawing.Size(196, 26);
            this.calisaniSilText.TabIndex = 98;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label35.Location = new System.Drawing.Point(850, 612);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(370, 20);
            this.label35.TabIndex = 99;
            this.label35.Text = "Silinecek/Düzenlenecek Çalışanın TC Numarası:";
            // 
            // bankaHesabiniSilText
            // 
            this.bankaHesabiniSilText.BackColor = System.Drawing.Color.MistyRose;
            this.bankaHesabiniSilText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bankaHesabiniSilText.Location = new System.Drawing.Point(1270, 865);
            this.bankaHesabiniSilText.Name = "bankaHesabiniSilText";
            this.bankaHesabiniSilText.Size = new System.Drawing.Size(196, 26);
            this.bankaHesabiniSilText.TabIndex = 100;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label36.Location = new System.Drawing.Point(815, 868);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(407, 20);
            this.label36.TabIndex = 101;
            this.label36.Text = "Silinecek / Düzenlenecek Bankanın Hesap Numarası:";
            // 
            // kisiyiAra
            // 
            this.kisiyiAra.BackColor = System.Drawing.Color.MistyRose;
            this.kisiyiAra.Location = new System.Drawing.Point(1484, 78);
            this.kisiyiAra.Name = "kisiyiAra";
            this.kisiyiAra.Size = new System.Drawing.Size(139, 45);
            this.kisiyiAra.TabIndex = 102;
            this.kisiyiAra.Text = "Kişiyi Bul ve Getir";
            this.kisiyiAra.UseVisualStyleBackColor = false;
            this.kisiyiAra.Click += new System.EventHandler(this.kisiyiAra_Click);
            // 
            // duzenlenecekKisi
            // 
            this.duzenlenecekKisi.BackColor = System.Drawing.Color.MistyRose;
            this.duzenlenecekKisi.Location = new System.Drawing.Point(1811, 78);
            this.duzenlenecekKisi.Name = "duzenlenecekKisi";
            this.duzenlenecekKisi.Size = new System.Drawing.Size(139, 45);
            this.duzenlenecekKisi.TabIndex = 103;
            this.duzenlenecekKisi.Text = "Düzenlemeyi Kaydet";
            this.duzenlenecekKisi.UseVisualStyleBackColor = false;
            this.duzenlenecekKisi.Click += new System.EventHandler(this.duzenlenecekKisi_Click);
            // 
            // sirketiBulVeGetir
            // 
            this.sirketiBulVeGetir.BackColor = System.Drawing.Color.MistyRose;
            this.sirketiBulVeGetir.Location = new System.Drawing.Point(1484, 400);
            this.sirketiBulVeGetir.Name = "sirketiBulVeGetir";
            this.sirketiBulVeGetir.Size = new System.Drawing.Size(139, 45);
            this.sirketiBulVeGetir.TabIndex = 104;
            this.sirketiBulVeGetir.Text = "Bul Ve Getir";
            this.sirketiBulVeGetir.UseVisualStyleBackColor = false;
            this.sirketiBulVeGetir.Click += new System.EventHandler(this.sirketiBulVeGetir_Click);
            // 
            // devletSirketininDuzenlemesi
            // 
            this.devletSirketininDuzenlemesi.BackColor = System.Drawing.Color.MistyRose;
            this.devletSirketininDuzenlemesi.Location = new System.Drawing.Point(1811, 400);
            this.devletSirketininDuzenlemesi.Name = "devletSirketininDuzenlemesi";
            this.devletSirketininDuzenlemesi.Size = new System.Drawing.Size(139, 45);
            this.devletSirketininDuzenlemesi.TabIndex = 105;
            this.devletSirketininDuzenlemesi.Text = "Düzenlemeyi Kaydet";
            this.devletSirketininDuzenlemesi.UseVisualStyleBackColor = false;
            this.devletSirketininDuzenlemesi.Click += new System.EventHandler(this.devletSirketininDuzenlemesi_Click);
            // 
            // ozelSirketiBulVeGetir
            // 
            this.ozelSirketiBulVeGetir.BackColor = System.Drawing.Color.MistyRose;
            this.ozelSirketiBulVeGetir.Location = new System.Drawing.Point(1484, 467);
            this.ozelSirketiBulVeGetir.Name = "ozelSirketiBulVeGetir";
            this.ozelSirketiBulVeGetir.Size = new System.Drawing.Size(139, 45);
            this.ozelSirketiBulVeGetir.TabIndex = 106;
            this.ozelSirketiBulVeGetir.Text = "Bul Ve Getir";
            this.ozelSirketiBulVeGetir.UseVisualStyleBackColor = false;
            this.ozelSirketiBulVeGetir.Click += new System.EventHandler(this.ozelSirketiBulVeGetir_Click);
            // 
            // ozelSirketinDuzenlenmesi
            // 
            this.ozelSirketinDuzenlenmesi.BackColor = System.Drawing.Color.MistyRose;
            this.ozelSirketinDuzenlenmesi.Location = new System.Drawing.Point(1811, 461);
            this.ozelSirketinDuzenlenmesi.Name = "ozelSirketinDuzenlenmesi";
            this.ozelSirketinDuzenlenmesi.Size = new System.Drawing.Size(139, 45);
            this.ozelSirketinDuzenlenmesi.TabIndex = 107;
            this.ozelSirketinDuzenlenmesi.Text = "Düzenlemeyi Kaydet";
            this.ozelSirketinDuzenlenmesi.UseVisualStyleBackColor = false;
            this.ozelSirketinDuzenlenmesi.Click += new System.EventHandler(this.ozelSirketinDuzenlenmesi_Click);
            // 
            // calisaniBulVeGetir
            // 
            this.calisaniBulVeGetir.BackColor = System.Drawing.Color.MistyRose;
            this.calisaniBulVeGetir.Location = new System.Drawing.Point(1484, 590);
            this.calisaniBulVeGetir.Name = "calisaniBulVeGetir";
            this.calisaniBulVeGetir.Size = new System.Drawing.Size(139, 45);
            this.calisaniBulVeGetir.TabIndex = 108;
            this.calisaniBulVeGetir.Text = "Bul Ve Getir";
            this.calisaniBulVeGetir.UseVisualStyleBackColor = false;
            this.calisaniBulVeGetir.Click += new System.EventHandler(this.calisaniBulVeGetir_Click);
            // 
            // calisaninDuzenlenmesi
            // 
            this.calisaninDuzenlenmesi.BackColor = System.Drawing.Color.MistyRose;
            this.calisaninDuzenlenmesi.Location = new System.Drawing.Point(1811, 590);
            this.calisaninDuzenlenmesi.Name = "calisaninDuzenlenmesi";
            this.calisaninDuzenlenmesi.Size = new System.Drawing.Size(139, 45);
            this.calisaninDuzenlenmesi.TabIndex = 109;
            this.calisaninDuzenlenmesi.Text = "Düzenlemeyi Kaydet";
            this.calisaninDuzenlenmesi.UseVisualStyleBackColor = false;
            this.calisaninDuzenlenmesi.Click += new System.EventHandler(this.calisaninDuzenlenmesi_Click);
            // 
            // sirketHesabiniBulVeGetir
            // 
            this.sirketHesabiniBulVeGetir.BackColor = System.Drawing.Color.MistyRose;
            this.sirketHesabiniBulVeGetir.Location = new System.Drawing.Point(1484, 818);
            this.sirketHesabiniBulVeGetir.Name = "sirketHesabiniBulVeGetir";
            this.sirketHesabiniBulVeGetir.Size = new System.Drawing.Size(139, 45);
            this.sirketHesabiniBulVeGetir.TabIndex = 110;
            this.sirketHesabiniBulVeGetir.Text = "Şirket Hesabını Bul ve Getir";
            this.sirketHesabiniBulVeGetir.UseVisualStyleBackColor = false;
            this.sirketHesabiniBulVeGetir.Click += new System.EventHandler(this.sirketHesabiniBulVeGetir_Click);
            // 
            // sirketHesabiniDuzenle
            // 
            this.sirketHesabiniDuzenle.BackColor = System.Drawing.Color.MistyRose;
            this.sirketHesabiniDuzenle.Location = new System.Drawing.Point(1811, 818);
            this.sirketHesabiniDuzenle.Name = "sirketHesabiniDuzenle";
            this.sirketHesabiniDuzenle.Size = new System.Drawing.Size(139, 45);
            this.sirketHesabiniDuzenle.TabIndex = 111;
            this.sirketHesabiniDuzenle.Text = "Şirket Hesabını Düzenle";
            this.sirketHesabiniDuzenle.UseVisualStyleBackColor = false;
            this.sirketHesabiniDuzenle.Click += new System.EventHandler(this.sirketHesabiniDuzenle_Click);
            // 
            // kisiselHesabiBulVeGetir
            // 
            this.kisiselHesabiBulVeGetir.BackColor = System.Drawing.Color.MistyRose;
            this.kisiselHesabiBulVeGetir.Location = new System.Drawing.Point(1484, 889);
            this.kisiselHesabiBulVeGetir.Name = "kisiselHesabiBulVeGetir";
            this.kisiselHesabiBulVeGetir.Size = new System.Drawing.Size(139, 45);
            this.kisiselHesabiBulVeGetir.TabIndex = 112;
            this.kisiselHesabiBulVeGetir.Text = "Kişisel Hesabını Bul ve Getir";
            this.kisiselHesabiBulVeGetir.UseVisualStyleBackColor = false;
            this.kisiselHesabiBulVeGetir.Click += new System.EventHandler(this.kisiselHesabiBulVeGetir_Click);
            // 
            // kisiselHesabiniDuzenle
            // 
            this.kisiselHesabiniDuzenle.BackColor = System.Drawing.Color.MistyRose;
            this.kisiselHesabiniDuzenle.Location = new System.Drawing.Point(1811, 889);
            this.kisiselHesabiniDuzenle.Name = "kisiselHesabiniDuzenle";
            this.kisiselHesabiniDuzenle.Size = new System.Drawing.Size(139, 45);
            this.kisiselHesabiniDuzenle.TabIndex = 113;
            this.kisiselHesabiniDuzenle.Text = "Kişisel Hesabını Düzenle";
            this.kisiselHesabiniDuzenle.UseVisualStyleBackColor = false;
            this.kisiselHesabiniDuzenle.Click += new System.EventHandler(this.kisiselHesabiniDuzenle_Click);
            // 
            // iletisimKoduText
            // 
            this.iletisimKoduText.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimKoduText.Location = new System.Drawing.Point(788, 164);
            this.iletisimKoduText.Name = "iletisimKoduText";
            this.iletisimKoduText.Size = new System.Drawing.Size(120, 22);
            this.iletisimKoduText.TabIndex = 114;
            // 
            // telNo
            // 
            this.telNo.BackColor = System.Drawing.Color.MistyRose;
            this.telNo.Location = new System.Drawing.Point(927, 164);
            this.telNo.Name = "telNo";
            this.telNo.Size = new System.Drawing.Size(120, 22);
            this.telNo.TabIndex = 115;
            // 
            // ePosta
            // 
            this.ePosta.BackColor = System.Drawing.Color.MistyRose;
            this.ePosta.Location = new System.Drawing.Point(1068, 164);
            this.ePosta.Name = "ePosta";
            this.ePosta.Size = new System.Drawing.Size(120, 22);
            this.ePosta.TabIndex = 116;
            // 
            // ilceKodu
            // 
            this.ilceKodu.BackColor = System.Drawing.Color.MistyRose;
            this.ilceKodu.Location = new System.Drawing.Point(1203, 164);
            this.ilceKodu.Name = "ilceKodu";
            this.ilceKodu.Size = new System.Drawing.Size(120, 22);
            this.ilceKodu.TabIndex = 117;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label37.Location = new System.Drawing.Point(785, 143);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(85, 16);
            this.label37.TabIndex = 118;
            this.label37.Text = "İletişim Kodu:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label38.Location = new System.Drawing.Point(924, 143);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(77, 16);
            this.label38.TabIndex = 119;
            this.label38.Text = "Telefon No:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label39.Location = new System.Drawing.Point(1065, 143);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 16);
            this.label39.TabIndex = 120;
            this.label39.Text = "E-Posta:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label40.Location = new System.Drawing.Point(1200, 143);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 16);
            this.label40.TabIndex = 121;
            this.label40.Text = "İlçe Kodu:";
            // 
            // iletisimEkle
            // 
            this.iletisimEkle.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimEkle.Location = new System.Drawing.Point(1350, 141);
            this.iletisimEkle.Name = "iletisimEkle";
            this.iletisimEkle.Size = new System.Drawing.Size(139, 45);
            this.iletisimEkle.TabIndex = 122;
            this.iletisimEkle.Text = "İletişimi Ekle";
            this.iletisimEkle.UseVisualStyleBackColor = false;
            this.iletisimEkle.Click += new System.EventHandler(this.iletisimEkle_Click);
            // 
            // iletisimiSil
            // 
            this.iletisimiSil.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimiSil.Location = new System.Drawing.Point(1650, 190);
            this.iletisimiSil.Name = "iletisimiSil";
            this.iletisimiSil.Size = new System.Drawing.Size(139, 45);
            this.iletisimiSil.TabIndex = 123;
            this.iletisimiSil.Text = "İletişimi Sil";
            this.iletisimiSil.UseVisualStyleBackColor = false;
            this.iletisimiSil.Click += new System.EventHandler(this.iletisimiSil_Click);
            // 
            // iletisimKodu
            // 
            this.iletisimKodu.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimKodu.Location = new System.Drawing.Point(1222, 216);
            this.iletisimKodu.Name = "iletisimKodu";
            this.iletisimKodu.Size = new System.Drawing.Size(196, 22);
            this.iletisimKodu.TabIndex = 124;
            // 
            // iletisimiDuzenle
            // 
            this.iletisimiDuzenle.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimiDuzenle.Location = new System.Drawing.Point(1811, 190);
            this.iletisimiDuzenle.Name = "iletisimiDuzenle";
            this.iletisimiDuzenle.Size = new System.Drawing.Size(139, 45);
            this.iletisimiDuzenle.TabIndex = 125;
            this.iletisimiDuzenle.Text = "Düzenlemeyi Kaydet";
            this.iletisimiDuzenle.UseVisualStyleBackColor = false;
            this.iletisimiDuzenle.Click += new System.EventHandler(this.iletisimiDuzenle_Click);
            // 
            // iletisimiBulVeGetir
            // 
            this.iletisimiBulVeGetir.BackColor = System.Drawing.Color.MistyRose;
            this.iletisimiBulVeGetir.Location = new System.Drawing.Point(1484, 190);
            this.iletisimiBulVeGetir.Name = "iletisimiBulVeGetir";
            this.iletisimiBulVeGetir.Size = new System.Drawing.Size(139, 45);
            this.iletisimiBulVeGetir.TabIndex = 126;
            this.iletisimiBulVeGetir.Text = "Bul Ve Getir";
            this.iletisimiBulVeGetir.UseVisualStyleBackColor = false;
            this.iletisimiBulVeGetir.Click += new System.EventHandler(this.iletisimiBulVeGetir_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label41.Location = new System.Drawing.Point(830, 218);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(344, 20);
            this.label41.TabIndex = 127;
            this.label41.Text = "Silinecek/Düzenlenecek İletişim Bilgisi Kodu:";
            // 
            // Iller
            // 
            this.Iller.BackColor = System.Drawing.Color.PeachPuff;
            this.Iller.Location = new System.Drawing.Point(526, 61);
            this.Iller.Name = "Iller";
            this.Iller.Size = new System.Drawing.Size(100, 36);
            this.Iller.TabIndex = 4;
            this.Iller.Text = "İller";
            this.Iller.UseVisualStyleBackColor = false;
            this.Iller.Click += new System.EventHandler(this.Iller_Click);
            // 
            // ilceleriGoster
            // 
            this.ilceleriGoster.BackColor = System.Drawing.Color.PeachPuff;
            this.ilceleriGoster.Location = new System.Drawing.Point(435, 61);
            this.ilceleriGoster.Name = "ilceleriGoster";
            this.ilceleriGoster.Size = new System.Drawing.Size(85, 36);
            this.ilceleriGoster.TabIndex = 128;
            this.ilceleriGoster.Text = "İlçeler";
            this.ilceleriGoster.UseVisualStyleBackColor = false;
            this.ilceleriGoster.Click += new System.EventHandler(this.ilceleriGoster_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label42.Location = new System.Drawing.Point(38, 219);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(201, 29);
            this.label42.TabIndex = 129;
            this.label42.Text = "FONKSİYONLAR";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PeachPuff;
            this.button1.Location = new System.Drawing.Point(82, 370);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(237, 36);
            this.button1.TabIndex = 130;
            this.button1.Text = "Evlilik Yüzdesini Göster";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PeachPuff;
            this.button2.Location = new System.Drawing.Point(435, 370);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(236, 36);
            this.button2.TabIndex = 131;
            this.button2.Text = "Toplam Kişi Sayısını Göster";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.PeachPuff;
            this.button3.Location = new System.Drawing.Point(551, 262);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(184, 36);
            this.button3.TabIndex = 132;
            this.button3.Text = "Hesabın Bakiyesini Göster";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // hesaptakiParayiGetirText
            // 
            this.hesaptakiParayiGetirText.BackColor = System.Drawing.Color.PeachPuff;
            this.hesaptakiParayiGetirText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.hesaptakiParayiGetirText.Location = new System.Drawing.Point(269, 272);
            this.hesaptakiParayiGetirText.Name = "hesaptakiParayiGetirText";
            this.hesaptakiParayiGetirText.Size = new System.Drawing.Size(180, 26);
            this.hesaptakiParayiGetirText.TabIndex = 133;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label43.Location = new System.Drawing.Point(39, 275);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(194, 20);
            this.label43.TabIndex = 134;
            this.label43.Text = "Hesap Numarası Giriniz:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label44.Location = new System.Drawing.Point(39, 326);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(160, 20);
            this.label44.TabIndex = 135;
            this.label44.Text = "Bakanlık Adı Giriniz:";
            // 
            // bakanlikAdiText
            // 
            this.bakanlikAdiText.BackColor = System.Drawing.Color.PeachPuff;
            this.bakanlikAdiText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bakanlikAdiText.Location = new System.Drawing.Point(269, 320);
            this.bakanlikAdiText.Name = "bakanlikAdiText";
            this.bakanlikAdiText.Size = new System.Drawing.Size(180, 26);
            this.bakanlikAdiText.TabIndex = 136;
            this.bakanlikAdiText.TextChanged += new System.EventHandler(this.bakanlikAdiText_TextChanged);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.PeachPuff;
            this.button4.Location = new System.Drawing.Point(480, 310);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(255, 36);
            this.button4.TabIndex = 137;
            this.button4.Text = "Bakanlığa Bağlı Şirket Sayısını Göster";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.bakanlikAdiText);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.hesaptakiParayiGetirText);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.ilceleriGoster);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.iletisimiBulVeGetir);
            this.Controls.Add(this.iletisimiDuzenle);
            this.Controls.Add(this.iletisimKodu);
            this.Controls.Add(this.iletisimiSil);
            this.Controls.Add(this.iletisimEkle);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.ilceKodu);
            this.Controls.Add(this.ePosta);
            this.Controls.Add(this.telNo);
            this.Controls.Add(this.iletisimKoduText);
            this.Controls.Add(this.kisiselHesabiniDuzenle);
            this.Controls.Add(this.kisiselHesabiBulVeGetir);
            this.Controls.Add(this.sirketHesabiniDuzenle);
            this.Controls.Add(this.sirketHesabiniBulVeGetir);
            this.Controls.Add(this.calisaninDuzenlenmesi);
            this.Controls.Add(this.calisaniBulVeGetir);
            this.Controls.Add(this.ozelSirketinDuzenlenmesi);
            this.Controls.Add(this.ozelSirketiBulVeGetir);
            this.Controls.Add(this.devletSirketininDuzenlemesi);
            this.Controls.Add(this.sirketiBulVeGetir);
            this.Controls.Add(this.duzenlenecekKisi);
            this.Controls.Add(this.kisiyiAra);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.bankaHesabiniSilText);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.calisaniSilText);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.ozelSirketiSilText);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.silinecekDevletSirketiText);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.kisiSilText);
            this.Controls.Add(this.bankaHesabiniSil);
            this.Controls.Add(this.calisaniSil);
            this.Controls.Add(this.ozelSirketiSil);
            this.Controls.Add(this.devletSirketiSil);
            this.Controls.Add(this.kisiSil);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.kisiselHesapAc);
            this.Controls.Add(this.sirketHesabiAc);
            this.Controls.Add(this.anneKizlikSoyad);
            this.Controls.Add(this.TCNo2);
            this.Controls.Add(this.sirketNo2);
            this.Controls.Add(this.hesapAcilisAmac2);
            this.Controls.Add(this.hesapTuru2);
            this.Controls.Add(this.hesabiKullananTCNo2);
            this.Controls.Add(this.olusturulmaTarihi2);
            this.Controls.Add(this.bakiye2);
            this.Controls.Add(this.hesapNumarasiNo2);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.maasNo1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.pozisyonNo1);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.calisanTCNo1);
            this.Controls.Add(this.sirketNo1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.calisanNo1);
            this.Controls.Add(this.calisanEkle);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.ozelSirketEkle);
            this.Controls.Add(this.calisanSayisii);
            this.Controls.Add(this.hisseMiktarii);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.sahipTCNoo);
            this.Controls.Add(this.bakanlikNumarasi);
            this.Controls.Add(this.kurulusTarihi);
            this.Controls.Add(this.bakanlikNoo);
            this.Controls.Add(this.kurulusTarihiii);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.iletisimKoduu);
            this.Controls.Add(this.sirketTuru);
            this.Controls.Add(this.sektor);
            this.Controls.Add(this.sirketAdi);
            this.Controls.Add(this.sirketNo);
            this.Controls.Add(this.devletSirketiEkle);
            this.Controls.Add(this.kisiselHesaplariGoster);
            this.Controls.Add(this.sirketHesaplariGoster);
            this.Controls.Add(this.bankaHesaplariGoster);
            this.Controls.Add(this.pozisyonlariGoster);
            this.Controls.Add(this.calisanlarGoster);
            this.Controls.Add(this.medeniDurumGoster);
            this.Controls.Add(this.ozelSirketleriGoster);
            this.Controls.Add(this.devletSirketleriGoster);
            this.Controls.Add(this.sirketleriGoster);
            this.Controls.Add(this.bakanliklariGoster);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.yeniKisiEkle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Iller);
            this.Controls.Add(this.bolgeleriGoster);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.iletisimBilgileriGoster);
            this.Controls.Add(this.kisiBilgileriGoster);
            this.Name = "Form1";
            this.Text = "Kişi ve İletişim Bilgileri";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.Button kisiBilgileriGoster;
        private System.Windows.Forms.Button iletisimBilgileriGoster;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button bolgeleriGoster;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button yeniKisiEkle;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Button bakanliklariGoster;
        private System.Windows.Forms.Button sirketleriGoster;
        private System.Windows.Forms.Button devletSirketleriGoster;
        private System.Windows.Forms.Button ozelSirketleriGoster;
        private System.Windows.Forms.Button medeniDurumGoster;
        private System.Windows.Forms.Button calisanlarGoster;
        private System.Windows.Forms.Button pozisyonlariGoster;
        private System.Windows.Forms.Button bankaHesaplariGoster;
        private System.Windows.Forms.Button sirketHesaplariGoster;
        private System.Windows.Forms.Button kisiselHesaplariGoster;
        private System.Windows.Forms.Button devletSirketiEkle;
        private System.Windows.Forms.TextBox sirketNo;
        private System.Windows.Forms.TextBox sirketAdi;
        private System.Windows.Forms.TextBox sektor;
        private System.Windows.Forms.TextBox sirketTuru;
        private System.Windows.Forms.TextBox iletisimKoduu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox kurulusTarihiii;
        private System.Windows.Forms.TextBox bakanlikNoo;
        private System.Windows.Forms.Label kurulusTarihi;
        private System.Windows.Forms.Label bakanlikNumarasi;
        private System.Windows.Forms.TextBox sahipTCNoo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox hisseMiktarii;
        private System.Windows.Forms.TextBox calisanSayisii;
        private System.Windows.Forms.Button ozelSirketEkle;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button calisanEkle;
        private System.Windows.Forms.TextBox calisanNo1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox sirketNo1;
        private System.Windows.Forms.TextBox calisanTCNo1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox pozisyonNo1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox maasNo1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox hesapNumarasiNo2;
        private System.Windows.Forms.TextBox bakiye2;
        private System.Windows.Forms.TextBox olusturulmaTarihi2;
        private System.Windows.Forms.TextBox hesabiKullananTCNo2;
        private System.Windows.Forms.TextBox hesapTuru2;
        private System.Windows.Forms.TextBox hesapAcilisAmac2;
        private System.Windows.Forms.TextBox sirketNo2;
        private System.Windows.Forms.TextBox TCNo2;
        private System.Windows.Forms.TextBox anneKizlikSoyad;
        private System.Windows.Forms.Button sirketHesabiAc;
        private System.Windows.Forms.Button kisiselHesapAc;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button kisiSil;
        private System.Windows.Forms.Button devletSirketiSil;
        private System.Windows.Forms.Button ozelSirketiSil;
        private System.Windows.Forms.Button calisaniSil;
        private System.Windows.Forms.Button bankaHesabiniSil;
        private System.Windows.Forms.TextBox kisiSilText;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox silinecekDevletSirketiText;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox ozelSirketiSilText;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox calisaniSilText;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox bankaHesabiniSilText;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button kisiyiAra;
        private System.Windows.Forms.Button duzenlenecekKisi;
        private System.Windows.Forms.Button sirketiBulVeGetir;
        private System.Windows.Forms.Button devletSirketininDuzenlemesi;
        private System.Windows.Forms.Button ozelSirketiBulVeGetir;
        private System.Windows.Forms.Button ozelSirketinDuzenlenmesi;
        private System.Windows.Forms.Button calisaniBulVeGetir;
        private System.Windows.Forms.Button calisaninDuzenlenmesi;
        private System.Windows.Forms.Button sirketHesabiniBulVeGetir;
        private System.Windows.Forms.Button sirketHesabiniDuzenle;
        private System.Windows.Forms.Button kisiselHesabiBulVeGetir;
        private System.Windows.Forms.Button kisiselHesabiniDuzenle;
        private System.Windows.Forms.TextBox iletisimKoduText;
        private System.Windows.Forms.TextBox telNo;
        private System.Windows.Forms.TextBox ePosta;
        private System.Windows.Forms.TextBox ilceKodu;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button iletisimEkle;
        private System.Windows.Forms.Button iletisimiSil;
        private System.Windows.Forms.TextBox iletisimKodu;
        private System.Windows.Forms.Button iletisimiDuzenle;
        private System.Windows.Forms.Button iletisimiBulVeGetir;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button Iller;
        private System.Windows.Forms.Button ilceleriGoster;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox hesaptakiParayiGetirText;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox bakanlikAdiText;
        private System.Windows.Forms.Button button4;
    }
}
